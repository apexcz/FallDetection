package knn;

public class Distance {

}
